<script src="<?php echo base_url("assets/js/jquery.min.js") ?>"></script>
<script src="<?php echo base_url("assets/js/popper.js") ?>"></script>
<script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>"></script>
<script src="<?php echo base_url("assets/js/jquery.validate.min.js") ?>"></script>
<script src="<?php echo base_url("assets/js/main.js") ?>"></script>

</body>

</html>